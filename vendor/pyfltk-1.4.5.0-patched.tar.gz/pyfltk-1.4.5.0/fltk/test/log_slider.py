#
# "$Id: log_slider.py 1 2025-10-25 21:39:48Z andreasheld $"
#
# Adjuster test program for pyFLTK the Python bindings
# for the Fast Light Tool Kit (FLTK).
#
# FLTK copyright 1998-1999 by Bill Spitzak and others.
# pyFLTK copyright 2003 by Andreas Held and others.
#
# This library is free software you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License, version 2.0 as published by the Free Software Foundation.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.
#
# You should have received a copy of the GNU Library General Public
# License along with this library if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
# USA.
#
# Please report all bugs and problems to "pyfltk-user@lists.sourceforge.net".
#

from fltk import *
import math

try:
    valuator_format_can_return_buffer = fltk.pyfltk_features['valuator_format_can_return_buffer']
except:
    valuator_format_can_return_buffer = False

if not valuator_format_can_return_buffer:
    raise Exception("This version of fltk cannot override Fl_Valuator::format(). You need to upgrade for log-sliders to work")

si_base_name = {-6: "um",
                -3: "mm",
                 0: "m",
                 3: "km"}

class LogSlider(Fl_Value_Slider):
    def _init__(x, y, w, h, label):
        Fl_Value_Slider.__init__(x,y,w,h,label)

    def format(self):
        x       = self.value()
        si_base = math.floor(x/3)*3
        return f"{10. ** (x - si_base):.0f}\n{si_base_name[si_base]}"


if __name__=='__main__':
    window = Fl_Window(800, 600, "Log-slider demo")
    slider = LogSlider(100,100, 600, 100, "Distance")
    slider.type(FL_HORIZONTAL)
    slider.bounds(-6, 3) # from 1um to 1km
    slider.step(1./8.)

    window.end();
    window.resizable()
    window.show()

    Fl.run()
