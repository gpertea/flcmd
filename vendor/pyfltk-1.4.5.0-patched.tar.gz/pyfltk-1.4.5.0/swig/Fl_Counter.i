/* File : Fl_Counter.i */
//%module Fl_Counter

%feature("docstring") ::Fl_Counter
"""
The Fl_Counter widget is provided for forms compatibility. It controls a 
single floating point value.
""" ;

%{
#include "FL/Fl_Counter.H"
%}

%include "macros.i"

CHANGE_OWNERSHIP(Fl_Counter)

SET_FORMAT_STRING_IN_TYPEMAP(char*, format_string)
SET_FORMAT_STRING_OUT_TYPEMAP(int, format, format_string)

%include "FL/Fl_Counter.H"

CLEAR_FORMAT_STRING_OUT_TYPEMAP(int, format)
