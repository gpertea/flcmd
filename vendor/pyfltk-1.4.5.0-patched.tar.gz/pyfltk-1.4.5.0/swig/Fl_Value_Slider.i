/* File : Fl_Value_Slider.i */
//%module Fl_Value_Slider

%feature("docstring") ::Fl_Value_Slider
"""
The Fl_Value_Slider widget is a Fl_Slider widget with a box displaying 
the current value.
""" ;

%{
#include "FL/Fl_Value_Slider.H"
%}

%include "macros.i"

CHANGE_OWNERSHIP(Fl_Value_Slider)

SET_FORMAT_STRING_IN_TYPEMAP(char*, format_string)
SET_FORMAT_STRING_OUT_TYPEMAP(int, format, format_string)

%include "FL/Fl_Value_Slider.H"

// clear the typemap for format_string
CLEAR_FORMAT_STRING_OUT_TYPEMAP(int, format)
