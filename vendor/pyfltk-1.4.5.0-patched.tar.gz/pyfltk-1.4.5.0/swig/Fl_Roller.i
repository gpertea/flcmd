/* File : Fl_Roller.i */
//%module Fl_Roller

%feature("docstring") ::Fl_Roller
"""
The Fl_Roller widget is a 'dolly' control commonly used to move 3D objects.
""" ;

%{
#include "FL/Fl_Roller.H"
%}

%include "macros.i"

CHANGE_OWNERSHIP(Fl_Roller)

SET_FORMAT_STRING_IN_TYPEMAP(char*, format_string)
SET_FORMAT_STRING_OUT_TYPEMAP(int, format, format_string)

%include "FL/Fl_Roller.H"

CLEAR_FORMAT_STRING_OUT_TYPEMAP(int, format)
