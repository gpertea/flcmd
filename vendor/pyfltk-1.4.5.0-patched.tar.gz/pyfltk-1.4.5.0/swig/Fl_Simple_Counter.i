/* File : Fl_Simple_Counter.i */
//%module Fl_Simple_Counter

%{
#include "FL/Fl_Simple_Counter.H"
%}

%include "macros.i"

CHANGE_OWNERSHIP(Fl_Simple_Counter)

SET_FORMAT_STRING_IN_TYPEMAP(char*, format_string)
SET_FORMAT_STRING_OUT_TYPEMAP(int, format, format_string)

%include "FL/Fl_Simple_Counter.H"

CLEAR_FORMAT_STRING_OUT_TYPEMAP(int, format)
